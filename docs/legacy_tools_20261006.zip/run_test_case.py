# -*- coding: utf-8 -*-
"""运行多路输出黑盒测试用例并回填数据与图片（命令行入口）。

用法：python run_test_case.py [--sheets ripple,dynamic,stability,startup] [--temp 25] [--output 路径]

按当前台架样机规格定义 PowerSpec 后，连接仪器 → 生成测试用例 → 逐工况执行 → 回填。
--output 可指定保存目录，或以 .xlsx 结尾的完整文件路径（路径由用户自己选择）。
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from auto_test.communication.serial_comm import SerialComm, InstrumentManager
from auto_test.communication.usbtmc_comm import UsbtmcComm
from auto_test.instruments import PowerSupply, ElectronicLoad, Oscilloscope, TempChamber
from auto_test.test_case import PowerSpec, OutputSpec, TestCaseRunner


def connect_instruments() -> dict:
    manager = InstrumentManager()
    detected = manager.detect_instruments()
    by_type = {}
    for port, info in detected.items():
        by_type[info.get("instrument_type")] = info
    instruments = {}
    if "power_supply" in by_type:
        info = by_type["power_supply"]
        comm = SerialComm()
        if comm.connect(info["port"], baud_rate=info.get("baud_rate") or 115200):
            ps = PowerSupply(comm); ps.connect(); instruments["power_supply"] = ps
            print(f"[连接] 直流源 {info['port']} {info['idn']}", flush=True)
    if "electronic_load" in by_type:
        info = by_type["electronic_load"]
        comm = SerialComm()
        if comm.connect(info["port"], baud_rate=info.get("baud_rate") or 9600):
            ld = ElectronicLoad(comm); ld.connect(); instruments["electronic_load"] = ld
            print(f"[连接] 电子负载 {info['port']} {info['idn']}", flush=True)
    if "oscilloscope" in by_type:
        info = by_type["oscilloscope"]
        comm = UsbtmcComm()
        if comm.connect(info["port"]):
            sc = Oscilloscope(comm); sc.connect(); sc.run(); instruments["oscilloscope"] = sc
            print(f"[连接] 示波器 {info['port']} {info['idn']}", flush=True)
    instruments["temp_chamber"] = TempChamber()
    return instruments


def default_spec() -> PowerSpec:
    """单路 BUCK 样机规格（12V/5A，Vin 32~60V）"""
    return PowerSpec(
        vin_min=32.0, vin_typ=48.0, vin_max=60.0,
        temp_min=-55.0, temp_typ=25.0, temp_max=110.0,
        outputs=[OutputSpec(name="CH1", vout_min=11.4, vout_typ=12.0, vout_max=12.6,
                            pout_min=0.0, pout_typ=60.0, pout_max=72.0, ripple_percent=3.0)],
    )


def main():
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sheets = tuple(sys.argv[sys.argv.index("--sheets") + 1].split(",")) if "--sheets" in sys.argv else ("ripple",)
    temp = None
    if "--temp" in sys.argv:
        try:
            temp = float(sys.argv[sys.argv.index("--temp") + 1])
        except (ValueError, IndexError):
            temp = 25.0

    # 输出路径由用户自己选择：目录或完整 .xlsx 路径
    output_arg = sys.argv[sys.argv.index("--output") + 1] if "--output" in sys.argv else None
    if output_arg:
        if output_arg.lower().endswith(".xlsx"):
            out_dir = os.path.dirname(os.path.abspath(output_arg))
            test_case_filename = os.path.basename(output_arg)
        else:
            out_dir = output_arg
            test_case_filename = "黑盒测试用例.xlsx"
    else:
        out_dir = os.path.join(os.getcwd(), "test_reports", "test_case_out")
        test_case_filename = "黑盒测试用例.xlsx"

    spec = default_spec()
    instruments = connect_instruments()
    if "power_supply" not in instruments or "electronic_load" not in instruments:
        print("缺少直流源/电子负载，中止")
        return 2

    # 源预置
    ps = instruments["power_supply"]
    ps.enable_output(False); time_import = __import__("time"); time_import.sleep(0.2)
    ps.set_voltage(spec.vin_typ); ps.set_current(6.5)

    runner = TestCaseRunner(spec, instruments, output_dir=out_dir, temp_filter=temp,
                             test_case_filename=test_case_filename)
    print(f"[执行] sheets={sheets} temp_filter={temp}", flush=True)
    path = runner.run(sheets=sheets)
    print("=" * 60, flush=True)
    print(f"测试用例已生成并回填: {path}", flush=True)
    print("=" * 60, flush=True)
    for inst in instruments.values():
        try:
            inst.disconnect()
        except Exception:
            pass
    return 0


if __name__ == "__main__":
    sys.exit(main())

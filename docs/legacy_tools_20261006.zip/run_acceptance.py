# -*- coding: utf-8 -*-
"""辅助电源研发版全量自动化测试上位机 —— 验收自检脚本（安全模式）。

本脚本连接真实仪器（直流源 / 电子负载 / 示波器），执行只读验证，不使能任何仪器输出，
用于在交付前验证「仪器通信 → 数据采集 → 测试矩阵 → 报告生成」整条链路。

输出：
  - 控制台汇总
  - test_reports/acceptance_<时间戳>/acceptance_report.json
  - test_reports/acceptance_<时间戳>/系统自检报告.xlsx
"""
import json
import os
import sys
import time
from datetime import datetime

# 确保可以从此脚本所在目录导入 auto_test 包
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from auto_test.communication.serial_comm import SerialComm, InstrumentManager
from auto_test.communication.usbtmc_comm import UsbtmcComm
from auto_test.instruments import PowerSupply, ElectronicLoad, Oscilloscope, TempChamber
from auto_test.config.project_config import (
    ProjectConfig, TestItemConfig, CriteriaSpec, ComponentProfile, OutputType, TopologyType
)
from auto_test.test_engine.test_matrix import TestMatrix
from auto_test.test_engine.results_store import TestResult, ResultsStore
from auto_test.reporting.report_generator import ReportGenerator
from auto_test.reporting.waveform_archiver import WaveformArchiver


def _fmt(v):
    return "" if v is None else str(v)


class Check:
    """单项验收检查结果"""

    def __init__(self, name, group):
        self.name = name
        self.group = group
        self.status = "PENDING"  # PASS / FAIL / ERROR
        self.detail = ""

    def pass_(self, detail=""):
        self.status = "PASS"
        self.detail = detail

    def fail(self, detail=""):
        self.status = "FAIL"
        self.detail = detail

    def error(self, detail=""):
        self.status = "ERROR"
        self.detail = detail

    def to_dict(self):
        return {"group": self.group, "name": self.name, "status": self.status, "detail": self.detail}


class AcceptanceRunner:
    def __init__(self):
        self.checks = []
        self.manager = InstrumentManager()
        self.instruments = {}  # 与主程序一致的命名空间
        self.connected = {}

    # ---------- 工具 ----------
    def _add(self, group, name):
        c = Check(name, group)
        self.checks.append(c)
        return c

    def _summarize(self):
        total = len(self.checks)
        passed = sum(1 for c in self.checks if c.status == "PASS")
        failed = sum(1 for c in self.checks if c.status == "FAIL")
        errors = sum(1 for c in self.checks if c.status == "ERROR")
        return total, passed, failed, errors

    # ---------- 阶段1：仪器检测与识别 ----------
    def phase_detect(self):
        g = "1.仪器检测与识别"
        try:
            detected = self.manager.detect_instruments()
            c = self._add(g, "扫描到仪器")
            if detected:
                c.pass_(f"发现 {len(detected)} 台仪器")
            else:
                c.fail("未发现任何仪器")
                return detected

            # 类型 -> 资源映射（同名多台时取最后一台，与主程序一致）
            by_type = {}
            for port, info in detected.items():
                itype = info.get("instrument_type")
                by_type[itype] = info

            for itype, label in [
                ("power_supply", "直流源"),
                ("electronic_load", "电子负载"),
                ("oscilloscope", "示波器"),
            ]:
                c = self._add(g, f"{label} 被识别")
                info = by_type.get(itype)
                if info:
                    c.pass_(f"{info.get('port')} | {info.get('idn')}")
                    self.connected[itype] = info
                else:
                    c.fail(f"未识别到 {label}")
            return detected
        except Exception as e:
            self._add(g, "仪器检测异常").error(str(e))
            return {}

    # ---------- 阶段2：连接与通信 ----------
    def phase_connect(self):
        g = "2.连接与只读通信"
        # 直流源
        info = self.connected.get("power_supply")
        if info:
            port = info["port"]
            baud = info.get("baud_rate") or 115200
            comm = SerialComm()
            c = self._add(g, f"直流源连接 {port}")
            if comm.connect(port, baud_rate=baud):
                c.pass_(f"波特率 {baud}")
                ps = PowerSupply(comm)
                ps.connect()
                self.instruments["power_supply"] = ps
                for cmd, label in [("VOLT?", "设定电压"), ("CURR?", "设定电流"), ("OUTP?", "输出状态"),
                                   ("MEAS:VOLT?", "实测电压"), ("MEAS:CURR?", "实测电流")]:
                    r = ps.query(cmd)
                    cc = self._add(g, f"直流源 {label}")
                    cc.pass_(_fmt(r))
            else:
                c.fail(comm.last_error)

        # 电子负载
        info = self.connected.get("electronic_load")
        if info:
            port = info["port"]
            baud = info.get("baud_rate") or 9600
            comm = SerialComm()
            c = self._add(g, f"电子负载连接 {port}")
            if comm.connect(port, baud_rate=baud):
                c.pass_(f"波特率 {baud}")
                ld = ElectronicLoad(comm)
                ld.connect()
                self.instruments["electronic_load"] = ld
                for cmd, label in [("FUNC?", "当前模式"), ("INP?", "输入状态"), ("VOLT?", "电压档")]:
                    r = ld.query(cmd)
                    cc = self._add(g, f"电子负载 {label}")
                    cc.pass_(_fmt(r))
            else:
                c.fail(comm.last_error)

        # 示波器
        info = self.connected.get("oscilloscope")
        if info:
            resource = info["port"]
            comm = UsbtmcComm()
            c = self._add(g, f"示波器连接 {resource}")
            if comm.connect(resource):
                c.pass_()
                scope = Oscilloscope(comm)
                scope.connect()
                self.instruments["oscilloscope"] = scope

                idn = scope.get_idn()
                cc = self._add(g, "示波器 IDN")
                cc.pass_(_fmt(idn))

                scope.run()
                time.sleep(1.0)
                w = scope.get_waveform_data(channel=1)
                cc = self._add(g, "示波器波形采集")
                if w is not None and len(w) > 0:
                    cc.pass_(f"{len(w)} 点, min={int(w.min())}, max={int(w.max())}, mean={w.mean():.1f}")
                else:
                    cc.fail("波形读取为空")
            else:
                c.fail(comm.last_error)

        # 温箱（预留）
        self.instruments["temp_chamber"] = TempChamber()
        c = self._add(g, "温箱（预留）")
        c.pass_("未连接（预留接口）")

    # ---------- 阶段3：测试矩阵生成 ----------
    def phase_matrix(self):
        g = "3.测试矩阵生成"
        cfg = self._default_config()
        try:
            matrix = TestMatrix(cfg)
            steps = matrix.generate()
            c = self._add(g, "矩阵生成")
            n_black = sum(1 for s in steps if s.test_type == "black_box")
            n_white = sum(1 for s in steps if s.test_type == "white_box")
            c.pass_(f"共 {len(steps)} 步（黑盒 {n_black} / 白盒 {n_white}）")
            c = self._add(g, "示波器配置自动生成")
            c.pass_(steps[0].scope_config if steps else "无步骤")
            return cfg, steps
        except Exception as e:
            self._add(g, "矩阵生成异常").error(str(e))
            return cfg, []

    # ---------- 阶段4：数据采集 + 报告生成 ----------
    def phase_report(self, cfg):
        g = "4.报告生成"
        out_root = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "test_reports",
            "acceptance_" + datetime.now().strftime("%Y%m%d_%H%M%S"),
        )
        archiver = WaveformArchiver(out_root)
        archiver.create_directory_structure()
        generator = ReportGenerator(cfg, archiver)

        store = ResultsStore()

        # 用真实只读数据生成样例结果，验证结果→报告链路
        ps = self.instruments.get("power_supply")
        ld = self.instruments.get("electronic_load")
        scope = self.instruments.get("oscilloscope")

        data = {}
        if ps is not None:
            data["ps_voltage"] = ps.measure_voltage()
            data["ps_current"] = ps.measure_current()
        if ld is not None:
            data["load_voltage"] = ld.get_voltage()
            data["load_current"] = ld.get_current()
        if scope is not None:
            w = scope.get_waveform_data(channel=1)
            if w is not None and len(w) > 0:
                data["waveform_points"] = len(w)
                data["v_avg_raw"] = float(w.mean())

        r = TestResult(
            step_id=1, test_item="系统自检", test_type="black_box",
            status="PASS", data=data,
        )
        store.add_result(r)

        try:
            black_path, white_path = generator.generate_both_reports(store.results, out_root)
            c = self._add(g, "Excel 报告生成")
            c.pass_(os.path.basename(black_path) if black_path else "无黑盒结果")
        except Exception as e:
            self._add(g, "Excel 报告生成异常").error(str(e))

        # JSON 验收报告（最后生成，使 JSON 内包含全部检查项）
        json_path = os.path.join(out_root, "acceptance_report.json")
        c_json = self._add(g, "JSON 验收报告")
        try:
            c_json.pass_(json_path)
            self.save_json(json_path)
        except Exception as e:
            c_json.error(str(e))

        return out_root

    # ---------- 默认配置 ----------
    def _default_config(self):
        cfg = ProjectConfig()
        cfg.model_name = "系统验收样机"
        cfg.output_type = OutputType.SINGLE
        cfg.topology = TopologyType.BUCK
        cfg.tester = "自动验收"
        cfg.test_date = datetime.now().strftime("%Y-%m-%d")
        cfg.output_channels[0].nominal_voltage = 12.0
        cfg.output_channels[0].nominal_current = 5.0
        cfg.test_items = [
            TestItemConfig(name="稳压精度", test_type="black_box", channel="CH1",
                           criteria=CriteriaSpec(12.6, 11.4, 12.0)),
            TestItemConfig(name="输出纹波与噪声", test_type="black_box", channel="CH1",
                           criteria=CriteriaSpec(0.5, 0.0, 0.0)),
        ]
        cfg.components = [ComponentProfile(ref_des="Q1", device_name="MOSFET", voltage_rating=100.0)]
        return cfg

    # ---------- 汇总 ----------
    def save_json(self, path):
        total, passed, failed, errors = self._summarize()
        payload = {
            "report_time": datetime.now().isoformat(),
            "project_name": "辅助电源研发版全量自动化测试上位机",
            "acceptance_type": "安全模式自检（不使能仪器输出）",
            "summary": {
                "total": total, "pass": passed, "fail": failed, "error": errors,
                "pass_rate": round(passed / total * 100, 2) if total else 0.0,
            },
            "instruments": {
                k: {"idn": v.get("idn"), "port": v.get("port"), "type": v.get("instrument_type")}
                for k, v in self.connected.items()
            },
            "checks": [c.to_dict() for c in self.checks],
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return payload

    def print_summary(self):
        print("\n" + "=" * 60)
        print("验收自检汇总")
        print("=" * 60)
        current_group = None
        for c in self.checks:
            if c.group != current_group:
                current_group = c.group
                print(f"\n【{c.group}】")
            mark = {"PASS": "✅ PASS", "FAIL": "❌ FAIL", "ERROR": "⚠ ERROR", "PENDING": "… PENDING"}[c.status]
            print(f"  {mark}  {c.name}" + (f"  →  {c.detail}" if c.detail else ""))
        total, passed, failed, errors = self._summarize()
        print("\n" + "-" * 60)
        print(f"合计 {total} 项 | 通过 {passed} | 失败 {failed} | 异常 {errors} | 通过率 {passed / total * 100:.1f}%" if total else "无检查项")
        print("=" * 60)
        return passed == total


def main():
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    runner = AcceptanceRunner()

    print("开始验收自检（安全模式）...")
    runner.phase_detect()
    runner.phase_connect()
    cfg, steps = runner.phase_matrix()
    runner.phase_report(cfg)

    ok = runner.print_summary()
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

# -*- coding: utf-8 -*-
"""辅助电源研发版 —— 全量黑盒实测（真实上电，需 DUT 已接好线）。

运行：python run_dut_test.py [--max-steps N]

流程：检测仪器 → 连接 → 生成黑盒矩阵 → 顺序执行 → 安全关断 → 生成报告。
温箱未连接，温度仅取 25℃（室温）；Vin 按边界 24/48/72V 遍历。
"""
import json
import os
import sys
import time
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from auto_test.communication.serial_comm import SerialComm, InstrumentManager
from auto_test.communication.usbtmc_comm import UsbtmcComm
from auto_test.instruments import PowerSupply, ElectronicLoad, Oscilloscope, TempChamber
from auto_test.config.project_config import (
    ProjectConfig, TestItemConfig, CriteriaSpec, OutputType, TopologyType
)
from auto_test.test_engine.test_matrix import TestMatrix
from auto_test.test_engine.test_executor import TestExecutor
from auto_test.test_engine.black_box_tests import BlackBoxTests
from auto_test.test_engine.white_box_tests import WhiteBoxTests
from auto_test.test_engine.results_store import ResultsStore
from auto_test.reporting.report_generator import ReportGenerator
from auto_test.reporting.waveform_archiver import WaveformArchiver


def log(msg: str):
    print(msg, flush=True)


def connect_instruments() -> dict:
    """检测并连接三台仪器，返回 {'power_supply':..., 'electronic_load':..., 'oscilloscope':..., 'temp_chamber':...}"""
    manager = InstrumentManager()
    detected = manager.detect_instruments()
    by_type = {}
    for port, info in detected.items():
        by_type[info.get("instrument_type")] = info

    instruments = {}
    if "power_supply" in by_type:
        info = by_type["power_supply"]
        comm = SerialComm()
        if comm.connect(info["port"], baud_rate=info.get("baud_rate") or 115200):
            ps = PowerSupply(comm)
            ps.connect()
            instruments["power_supply"] = ps
            log(f"[连接] 直流源 {info['port']} -> {info['idn']}")
        else:
            log(f"[连接失败] 直流源: {comm.last_error}")
    if "electronic_load" in by_type:
        info = by_type["electronic_load"]
        comm = SerialComm()
        if comm.connect(info["port"], baud_rate=info.get("baud_rate") or 9600):
            ld = ElectronicLoad(comm)
            ld.connect()
            instruments["electronic_load"] = ld
            log(f"[连接] 电子负载 {info['port']} -> {info['idn']}")
        else:
            log(f"[连接失败] 电子负载: {comm.last_error}")
    if "oscilloscope" in by_type:
        info = by_type["oscilloscope"]
        comm = UsbtmcComm()
        if comm.connect(info["port"]):
            scope = Oscilloscope(comm)
            scope.connect()
            scope.run()
            instruments["oscilloscope"] = scope
            log(f"[连接] 示波器 {info['port']} -> {info['idn']}")
        else:
            log(f"[连接失败] 示波器: {comm.last_error}")
    instruments["temp_chamber"] = TempChamber()  # 预留
    return instruments


def build_config() -> ProjectConfig:
    cfg = ProjectConfig()
    cfg.model_name = "DUT样机"
    cfg.output_type = OutputType.SINGLE
    cfg.topology = TopologyType.BUCK
    cfg.tester = "自动实测"
    cfg.test_date = datetime.now().strftime("%Y-%m-%d")

    # 边界：Vin 24/48/60，温度仅 25（温箱未连接）
    # 注：直流源 SPM6103 最高输出 60V，故 vin_max 取 60（DUT 标称 72V 上限受源限制）
    cfg.boundary.vin_min = 24.0
    cfg.boundary.vin_rated = 48.0
    cfg.boundary.vin_max = 60.0
    cfg.boundary.vin_list = [24.0, 48.0, 60.0]
    cfg.boundary.temp_min = 25.0
    cfg.boundary.temp_rated = 25.0
    cfg.boundary.temp_max = 25.0
    cfg.boundary.temp_list = [25.0]
    cfg.boundary.switch_freq = 100e3

    ch = cfg.output_channels[0]
    ch.channel_name = "CH1"
    ch.nominal_voltage = 12.0
    ch.nominal_current = 5.0
    ch.iout_min = 0.1
    ch.iout_half = 2.5
    ch.iout_rated = 5.0
    ch.iout_max = 6.0
    cfg.boundary.iout_min = 0.1
    cfg.boundary.iout_half = 2.5
    cfg.boundary.iout_rated = 5.0
    cfg.boundary.iout_max = 6.0

    cfg.test_items = [
        TestItemConfig(name="稳压精度", test_type="black_box", channel="CH1",
                       criteria=CriteriaSpec(12.6, 11.4, 12.0)),
        TestItemConfig(name="输出纹波与噪声", test_type="black_box", channel="CH1",
                       criteria=CriteriaSpec(0.5, 0.0, 0.0)),
        TestItemConfig(name="开关机时序", test_type="black_box", channel="CH1",
                       criteria=CriteriaSpec(100.0, 0.0, 0.0)),
    ]
    return cfg


def main():
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    max_steps = None
    if "--max-steps" in sys.argv:
        try:
            max_steps = int(sys.argv[sys.argv.index("--max-steps") + 1])
        except (ValueError, IndexError):
            pass

    log("=" * 60)
    log("全量黑盒实测开始")
    log("=" * 60)

    instruments = connect_instruments()
    if "power_supply" not in instruments or "electronic_load" not in instruments:
        log("缺少必要仪器（直流源/电子负载），中止。")
        return 2

    cfg = build_config()

    # 直流源预置：关闭输出、初始电压、放宽电流限值（源最大 6.5A）
    ps = instruments.get("power_supply")
    if ps:
        ps.enable_output(False)
        time.sleep(0.2)
        ps.set_voltage(cfg.boundary.vin_min)
        ps.set_current(6.5)
        log(f"[源预置] 电压={cfg.boundary.vin_min}V, 电流限值=6.5A, 输出关")

    matrix = TestMatrix(cfg)
    all_steps = matrix.generate()
    steps = [s for s in all_steps if s.test_type == "black_box"]
    if max_steps:
        steps = steps[:max_steps]
    log(f"[矩阵] 黑盒步骤 {len(steps)} 步（全量矩阵 {len(all_steps)} 步）")

    out_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "test_reports",
        "dut_test_" + datetime.now().strftime("%Y%m%d_%H%M%S"),
    )
    archiver = WaveformArchiver(out_dir)
    archiver.create_directory_structure()

    store = ResultsStore()
    executor = TestExecutor(instruments, store)
    executor.set_channel_configs(cfg.output_channels)
    executor.set_archiver(archiver)
    executor.set_test_handlers(BlackBoxTests(cfg), WhiteBoxTests(cfg))

    total = len(steps)
    executor.set_callback("step_start", lambda **kw: log(
        f"  [{kw['index'] + 1}/{kw['total']}] 开始: {kw['step'].test_item} "
        f"(mode={kw['step'].test_mode}, Vin={kw['step'].vin}V, Iout={kw['step'].iout}A, T={kw['step'].temp}C)"
    ))
    executor.set_callback("step_complete", lambda **kw: log(
        f"  [{kw['index'] + 1}/{kw['total']}] {kw['result'].status}: {kw['step'].test_item}"
    ))
    executor.set_callback("step_error", lambda **kw: log(
        f"  [{kw['index'] + 1}/{kw['total']}] ERROR: {kw['step'].test_item}: {kw['error']}"
    ))
    executor.set_callback("all_complete", lambda **kw: log("全部步骤执行完成。"))

    t0 = time.time()
    try:
        executor.run(steps)
    except Exception as e:
        log(f"[异常] 执行器异常: {e}")
        import traceback
        log(traceback.format_exc())
    finally:
        # 双保险：确保仪器输出关断
        executor._shutdown_instruments()
        log("[安全] 已关断直流源输出与电子负载输入")

    elapsed = time.time() - t0
    log(f"[耗时] {elapsed / 60:.1f} 分钟")

    # 汇总
    n_pass = store.get_pass_count()
    n_fail = store.get_fail_count()
    n_err = store.get_error_count()
    n_skip = len(store.results) - n_pass - n_fail - n_err
    log(f"[结果] 总计 {len(store.results)} | PASS {n_pass} | FAIL {n_fail} | ERROR {n_err} | SKIP {n_skip}")

    # 报告
    generator = ReportGenerator(cfg, archiver)
    black_path, _ = generator.generate_both_reports(store.results, out_dir)

    summary = {
        "report_time": datetime.now().isoformat(),
        "project_name": "辅助电源研发版全量自动化测试上位机",
        "test_type": "黑盒全量实测",
        "config": {
            "model": cfg.model_name, "topology": cfg.topology.value,
            "vin_list": cfg.boundary.vin_list, "temp_list": cfg.boundary.temp_list,
            "nominal_voltage": cfg.output_channels[0].nominal_voltage,
        },
        "summary": {
            "total": len(store.results), "pass": n_pass, "fail": n_fail,
            "error": n_err, "skip": n_skip,
            "pass_rate": round(n_pass / len(store.results) * 100, 2) if store.results else 0.0,
        },
        "results": [r.to_dict() for r in store.results],
    }
    json_path = os.path.join(out_dir, "dut_test_summary.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    log("=" * 60)
    log(f"输出目录: {out_dir}")
    log(f"Excel 报告: {black_path}")
    log(f"JSON 汇总: {json_path}")
    log("=" * 60)

    # 断开所有仪器
    for inst in instruments.values():
        try:
            inst.disconnect()
        except Exception:
            pass
    log("[断开] 已断开所有仪器")
    return 0


if __name__ == "__main__":
    sys.exit(main())

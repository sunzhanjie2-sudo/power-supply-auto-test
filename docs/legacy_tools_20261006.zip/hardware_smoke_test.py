"""真机冒烟测试：逐台验证电源 / 电子负载 / 示波器驱动在真实硬件上的可用性。

用法：
    python hardware_smoke_test.py            # 全部仪器
    python hardware_smoke_test.py ps         # 仅电源
    python hardware_smoke_test.py load       # 仅电子负载
    python hardware_smoke_test.py scope      # 仅示波器

安全策略：电源默认只做只读回读验证；加 --output 才会以低压(5V/0.5A限流)
短时开启输出并测量后关闭。电子负载输入保持关闭，仅验证命令与测量回读。
"""
import sys
import time

from auto_test.communication.serial_comm import InstrumentManager
from auto_test.instruments import PowerSupply, ElectronicLoad, Oscilloscope

PASS, FAIL = "通过", "失败"
results = []


def record(name, ok, detail=""):
    results.append((name, ok, detail))
    print(f"  [{'√' if ok else '×'}] {name}" + (f"  -> {detail}" if detail else ""))


def smoke_power_supply(output_test: bool):
    print("\n===== 电源 OWON SPM6103 (COM4 @115200) =====")
    comm = SerialCommX()
    if not comm.connect("COM4", baud_rate=115200):
        record("电源串口连接", False, comm.last_error)
        return
    ps = PowerSupply(comm)
    ps.connect()

    idn = ps.get_idn()
    record("*IDN?", bool(idn), idn or "无响应")

    ps.set_voltage(12.0)
    time.sleep(0.15)
    v_set = ps.get_voltage()
    record("VOLT 设定/回读", abs(v_set - 12.0) < 0.1, f"回读 {v_set}")

    ps.set_current(1.0)
    time.sleep(0.15)
    i_set = ps.get_current()
    record("CURR 设定/回读", abs(i_set - 1.0) < 0.1, f"回读 {i_set}")

    meas = ps.measure_all()
    record("MEAS:ALL? 测量", meas["power"] >= 0, str(meas))

    if output_test:
        print("  -- 输出测试 (5V / 0.5A 限流，3 秒后关闭) --")
        ps.initialize(voltage=5.0, current=0.5)
        ps.enable_output(True)
        time.sleep(3)
        v = ps.measure_voltage()
        i = ps.measure_current()
        record("输出开启后测量", v > 0.5, f"V={v:.3f} I={i:.3f}")
        ps.shutdown()
        time.sleep(0.5)
        record("输出关闭", not ps.get_output_state(), f"OUTP?={ps.query('OUTP?')}")
    else:
        ps.shutdown()

    comm.disconnect()


def smoke_electronic_load():
    print("\n===== 电子负载 UNI-T UTL8212 (COM3 @9600) =====")
    comm = SerialCommX()
    if not comm.connect("COM3", baud_rate=9600):
        record("负载串口连接", False, comm.last_error)
        return
    load = ElectronicLoad(comm)
    load.connect()

    idn = load.get_idn()
    record("*IDN?", bool(idn), idn or "无响应")

    mode = load.get_mode()
    record("FUNC? 模式查询", mode is not None, f"当前模式 {mode}")

    load.enable_input(False)
    time.sleep(0.2)
    state = load.get_input_state()
    record("INP? 输入状态查询", state is not None, f"输入 {'ON' if state else 'OFF'}")

    load.set_current(0.5)
    time.sleep(0.3)
    i_set = load.get_current()
    record("CURR 设定/回读", i_set is not None and abs(i_set - 0.5) < 0.05, f"回读 {i_set}")

    v = load.measure_voltage()
    i = load.measure_current()
    record("MEAS 测量回读", v is not None, f"V={v} I={i}")

    comm.disconnect()


def smoke_oscilloscope():
    print("\n===== 示波器 Rigol DS1152E (USB-TMC) =====")
    from auto_test.communication.usbtmc_comm import UsbtmcComm
    comm = UsbtmcComm()
    if not comm.connect("USB0::0x1AB1::0x0588::DS1EI182307208::INSTR"):
        record("示波器 USB 连接", False, comm.last_error)
        return
    scope = Oscilloscope(comm)
    scope.connect()

    idn = scope.get_idn()
    record("*IDN?", bool(idn), idn or "无响应")

    scale = scope.get_channel_scale(1)
    record("CHAN1:SCAL? 回读", scale is not None, f"{scale} V/div")

    tb = scope.get_timebase_scale()
    record("TIM:SCAL? 回读", tb is not None, f"{tb} s/div")

    ok = scope.set_channel_scale(1, 1.0) is not False
    record("CHAN1:SCAL 设置", ok)
    scope.set_channel_scale(1, scale if scale else 1.0)

    pre = scope.get_waveform_preamble()
    record("WAV:PRE? 前导", pre is not None, str(pre))

    data = scope.get_waveform_data_volts(1)
    if data is not None and len(data) > 0:
        import numpy as np
        record("波形读取", True, f"{len(data)} 点, Vpp={np.ptp(data):.3f}V")
    else:
        record("波形读取", False, "无数据")

    comm.disconnect()


def SerialCommX():
    from auto_test.communication.serial_comm import SerialComm
    return SerialComm()


if __name__ == "__main__":
    args = [a.lower() for a in sys.argv[1:]]
    targets = args or ["ps", "load", "scope"]
    if "ps" in targets:
        smoke_power_supply(output_test="--output" in args)
    if "load" in targets:
        smoke_electronic_load()
    if "scope" in targets:
        smoke_oscilloscope()

    print("\n===== 汇总 =====")
    failed = [r for r in results if not r[1]]
    print(f"共 {len(results)} 项，通过 {len(results) - len(failed)}，失败 {len(failed)}")
    for name, _, detail in failed:
        print(f"  失败: {name}  {detail}")
    sys.exit(1 if failed else 0)

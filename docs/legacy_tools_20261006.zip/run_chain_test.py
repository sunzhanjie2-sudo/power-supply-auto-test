"""真机链路验证：连接全部仪器 -> 生成测试矩阵 -> 执行器真机跑一轮 -> 生成报告。

用最小工况验证完整执行链路（电源 48V 输入、0.5A 限流，稳压精度 + 纹波两项），
不依赖 GUI。运行前确认 DUT 输入侧已接到直流源输出端子。
"""
import os
import sys
import time

from auto_test.communication.serial_comm import InstrumentManager
from auto_test.instruments import PowerSupply, ElectronicLoad, Oscilloscope, TempChamber
from auto_test.config.project_config import (
    ProjectConfig, OutputType, TopologyType, OutputChannelConfig,
    BoundaryParams, TestItemConfig, CriteriaSpec,
)
from auto_test.test_engine.test_matrix import TestMatrix
from auto_test.test_engine.test_executor import TestExecutor
from auto_test.test_engine.black_box_tests import BlackBoxTests
from auto_test.test_engine.white_box_tests import WhiteBoxTests
from auto_test.test_engine.results_store import ResultsStore
from auto_test.reporting.report_generator import ReportGenerator
from auto_test.reporting.waveform_archiver import WaveformArchiver


def build_instruments(manager: InstrumentManager) -> dict:
    detected = manager.detect_instruments()
    if not detected:
        print("未发现任何仪器，请检查连接")
        sys.exit(1)

    instruments = {}
    detected_info = {}
    for port, info in detected.items():
        itype = info["instrument_type"]
        name = f"{itype}_{port}"
        manager.add_instrument(name, port, itype, info.get("comm_type", "serial"),
                               info.get("baud_rate", 9600))
        comm = manager.get_instrument(name)
        if comm and comm.is_connected:
            detected_info[itype] = {"comm": comm, "info": info}
            print(f"已连接: {itype} @ {port}  IDN={info['idn']}")

    if "power_supply" in detected_info:
        ps = PowerSupply(detected_info["power_supply"]["comm"])
        ps.connect()
        instruments["power_supply"] = ps
    if "electronic_load" in detected_info:
        load = ElectronicLoad(detected_info["electronic_load"]["comm"])
        load.connect()
        instruments["electronic_load"] = load
    if "oscilloscope" in detected_info:
        scope = Oscilloscope(detected_info["oscilloscope"]["comm"])
        scope.connect()
        instruments["oscilloscope"] = scope
    instruments["temp_chamber"] = TempChamber()
    return instruments


def build_config() -> ProjectConfig:
    cfg = ProjectConfig()
    cfg.model_name = "链路验证样机"
    cfg.output_type = OutputType.SINGLE
    cfg.topology = TopologyType.BUCK
    cfg.output_channels = [OutputChannelConfig(
        channel_name="CH1", nominal_voltage=12.0,
        iout_min=0.1, iout_half=0.25, iout_rated=0.4, iout_max=0.5,
    )]
    cfg.boundary = BoundaryParams(vin_list=[48.0], vin_min=48.0, vin_rated=48.0, vin_max=48.0,
                                  temp_list=[25.0])
    cfg.test_items = [
        TestItemConfig(name="稳压精度", test_type="black_box", channel="CH1",
                       criteria=CriteriaSpec(lower_limit=11.4, upper_limit=12.6, nominal_value=12.0, unit="V")),
        TestItemConfig(name="输出纹波与噪声", test_type="black_box", channel="CH1",
                       criteria=CriteriaSpec(upper_limit=0.5, unit="V")),
    ]
    return cfg


def main():
    manager = InstrumentManager()
    instruments = build_instruments(manager)
    if "power_supply" not in instruments or "electronic_load" not in instruments:
        print("电源或电子负载未连接，中止链路测试")
        sys.exit(1)

    # 安全限流：链路验证限制 0.5A
    instruments["power_supply"].set_current(0.5)

    config = build_config()
    matrix = TestMatrix(config)
    steps = matrix.generate()
    # 只跑本脚本配置的测试项（矩阵可能含动态响应等，此处仅保留配置内项目）
    item_names = {t.name for t in config.test_items}
    steps = [s for s in steps if s.test_item in item_names]
    print(f"\n生成 {len(steps)} 个测试步骤:")
    for s in steps:
        print(f"  #{s.step_id} {s.test_item} vin={s.vin} iout={s.iout} mode={s.test_mode}")

    output_root = os.path.join(os.getcwd(), "test_reports", "chain_out")
    archiver = WaveformArchiver(output_root)
    archiver.create_directory_structure()

    results_store = ResultsStore()
    executor = TestExecutor(instruments, results_store)
    executor.set_channel_configs(config.output_channels)
    executor.set_archiver(archiver)
    executor.set_test_handlers(BlackBoxTests(config), WhiteBoxTests(config))
    executor.set_callback("step_complete", lambda step, result, index, total:
        print(f"  [{index+1}/{total}] {step.test_item} vin={step.vin} iout={step.iout} -> {result.status}"
              + (f"  data={result.data}" if result.status != "PASS" else "")))
    executor.set_callback("step_error", lambda step, error, index, total:
        print(f"  [{index+1}/{total}] {step.test_item} 异常: {error}"))

    print("\n开始执行（电源将输出 48V，负载带载 0.1~0.5A）...")
    executor.run(steps)

    print(f"\n执行完成，状态={executor.status.value}")
    print(f"结果: 共{results_store.get_total()} PASS={results_store.get_pass_count()} "
          f"FAIL={results_store.get_fail_count()} ERROR={results_store.get_error_count()}")

    # 导出结果与报告
    csv_path = os.path.join(output_root, "chain_results.csv")
    results_store.export_csv(csv_path)
    report = ReportGenerator(config, archiver)
    paths = report.generate_both_reports(
        results_store.results if hasattr(results_store, "results") else results_store.get_black_box_results(),
        output_root,
    )
    print(f"结果CSV: {csv_path}")
    print(f"报告: {paths}")

    manager.close_all()


if __name__ == "__main__":
    main()
